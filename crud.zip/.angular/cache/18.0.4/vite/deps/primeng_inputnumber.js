import {
  INPUTNUMBER_VALUE_ACCESSOR,
  InputNumber,
  InputNumberModule
} from "./chunk-XKLDDIGQ.js";
import "./chunk-3M6SINA2.js";
import "./chunk-XIHFJRFG.js";
import "./chunk-YO4QQFN2.js";
import "./chunk-D6NBZG3Z.js";
import "./chunk-UWZHSQRF.js";
import "./chunk-LAPS46TG.js";
import "./chunk-TKJMWDM5.js";
import "./chunk-5ZG76YS2.js";
import "./chunk-X5DVJFD2.js";
import "./chunk-BNSKJIBN.js";
export {
  INPUTNUMBER_VALUE_ACCESSOR,
  InputNumber,
  InputNumberModule
};
//# sourceMappingURL=primeng_inputnumber.js.map
