import {
  SELECTBUTTON_VALUE_ACCESSOR,
  SelectButton,
  SelectButtonModule
} from "./chunk-CS2SOQX6.js";
import "./chunk-YO4QQFN2.js";
import "./chunk-LAPS46TG.js";
import "./chunk-TKJMWDM5.js";
import "./chunk-5ZG76YS2.js";
import "./chunk-X5DVJFD2.js";
import "./chunk-BNSKJIBN.js";
export {
  SELECTBUTTON_VALUE_ACCESSOR,
  SelectButton,
  SelectButtonModule
};
//# sourceMappingURL=primeng_selectbutton.js.map
