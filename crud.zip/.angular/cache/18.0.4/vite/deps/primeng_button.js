import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-D6NBZG3Z.js";
import "./chunk-UWZHSQRF.js";
import "./chunk-LAPS46TG.js";
import "./chunk-TKJMWDM5.js";
import "./chunk-5ZG76YS2.js";
import "./chunk-X5DVJFD2.js";
import "./chunk-BNSKJIBN.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
