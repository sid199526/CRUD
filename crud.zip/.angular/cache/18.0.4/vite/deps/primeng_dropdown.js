import {
  DROPDOWN_VALUE_ACCESSOR,
  Dropdown,
  DropdownItem,
  DropdownModule
} from "./chunk-6XCMAKCK.js";
import "./chunk-3M6SINA2.js";
import "./chunk-YO4QQFN2.js";
import "./chunk-F6IJ26N2.js";
import "./chunk-UWZHSQRF.js";
import "./chunk-LAPS46TG.js";
import "./chunk-TKJMWDM5.js";
import "./chunk-5ZG76YS2.js";
import "./chunk-X5DVJFD2.js";
import "./chunk-BNSKJIBN.js";
export {
  DROPDOWN_VALUE_ACCESSOR,
  Dropdown,
  DropdownItem,
  DropdownModule
};
//# sourceMappingURL=primeng_dropdown.js.map
