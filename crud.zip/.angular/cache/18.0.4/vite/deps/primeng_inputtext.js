import {
  InputText,
  InputTextModule
} from "./chunk-XIHFJRFG.js";
import "./chunk-YO4QQFN2.js";
import "./chunk-5ZG76YS2.js";
import "./chunk-X5DVJFD2.js";
import "./chunk-BNSKJIBN.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
